/*
 * Copyright (c) OSGi Alliance (2011, 2016). All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Service Component Annotations Package Version 1.4.
 * <p>
 * This package is not used at runtime. Annotated classes are processed by tools
 * to generate Component Descriptions which are used at runtime.
 *
 * @author $Id: 1fc3ff6852cbc34e6c0de294c8ae94325e98f06a $
 */

@Version(COMPONENT_SPECIFICATION_VERSION)
package aQute.bnd.component.annotations;

import static aQute.bnd.component.ComponentConstants.COMPONENT_SPECIFICATION_VERSION;

import org.osgi.annotation.versioning.Version;

