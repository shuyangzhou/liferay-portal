aui-component
========
